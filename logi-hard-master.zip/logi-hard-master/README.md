Logi-hard
=========

All Logi specific HDL code (platform specific interface, extension boards, specific hdl, etc)